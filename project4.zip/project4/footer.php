</main>
</body>
<footer>
<p>
    <a href="index.php">Home</a><span class="spacer"></span>
    <a href=https://www.isthmusvocalensemble.org/ target="summat">Visit IVE's Website</a>
</p>
</footer>