<?php
    // Define database connection constants
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PW', '');
    define('DB_NAME', 'IVE');
?>
